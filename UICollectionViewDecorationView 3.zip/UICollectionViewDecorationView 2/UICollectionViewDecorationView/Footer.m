//
//  Footer.m
//  UICollectionViewDecorationView
//
//  Created by 魏鹏程 on 2017/1/16.
//  Copyright © 2017年 魏鹏程. All rights reserved.
//

#import "Footer.h"

@implementation Footer

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
