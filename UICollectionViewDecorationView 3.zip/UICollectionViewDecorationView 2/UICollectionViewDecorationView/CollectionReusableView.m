//
//  CollectionReusableView.m
//  UICollectionViewDecorationView
//
//  Created by 魏鹏程 on 16/6/19.
//  Copyright © 2016年 魏鹏程. All rights reserved.
//

#import "CollectionReusableView.h"
#import "MyCustomLayout.h"

@implementation CollectionReusableView
//- (void)applyLayoutAttributes:(UICollectionViewLayoutAttributes *)layoutAttributes {
//    [super applyLayoutAttributes:layoutAttributes];
//    
//    ECCollectionViewLayoutAttributes *ecLayoutAttributes = (ECCollectionViewLayoutAttributes*)layoutAttributes;
//    self.backgroundColor = ecLayoutAttributes.color;
//}

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if(self)
    {
        self.backgroundColor=[UIColor greenColor];
    }
    return self;
}

@end
