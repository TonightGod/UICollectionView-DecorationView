//
//  MyCustomLayout.m
//  UICollectionViewDecorationView
//
//  Created by 魏鹏程 on 16/6/19.
//  Copyright © 2016年 魏鹏程. All rights reserved.
//

#import "MyCustomLayout.h"
#import "CollectionReusableView.h"

@interface MyCustomLayout()
@property(nonatomic,strong) NSMutableArray *decorationViews;
@end


@implementation MyCustomLayout


-(NSMutableArray*)decorationViews
{
    if(!_decorationViews)
    {
        _decorationViews=[NSMutableArray array];
    }
    return _decorationViews;
}


- (void)prepareLayout {
    [super prepareLayout];
    
    [self.decorationViews removeAllObjects];
    NSInteger sections=[self.collectionView numberOfSections];
    for(NSInteger section=0;section<sections;section++)
    {
        NSInteger items=[self.collectionView numberOfItemsInSection:section];
        if(items>0)
        {
            CGRect firstItemFrame=[self layoutAttributesForItemAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:section]].frame;
            CGRect lastItemFrame=[self layoutAttributesForItemAtIndexPath:[NSIndexPath indexPathForRow:items-1 inSection:section]].frame;
            UIEdgeInsets sectionInset=self.sectionInset;
            if([self.collectionView.delegate respondsToSelector:@selector(collectionView:layout:insetForSectionAtIndex:)])
            {
                sectionInset = [(id<UICollectionViewDelegateFlowLayout>)self.collectionView.delegate collectionView:self.collectionView layout:self insetForSectionAtIndex:section];
            }
            
            CGRect sectionFrame=CGRectUnion(firstItemFrame, lastItemFrame);
            sectionFrame.origin.x=0;
            sectionFrame.origin.y-=sectionInset.top;
            if(self.scrollDirection==UICollectionViewScrollDirectionHorizontal)
            {
                sectionFrame.size.width += sectionInset.left + sectionInset.right;
                sectionFrame.size.height = self.collectionView.frame.size.height;
            }else
            {
                sectionFrame.size.width = self.collectionView.frame.size.width;
                sectionFrame.size.height += sectionInset.top + sectionInset.bottom;
            }
            
            NSString *identifer=[self.delegate collectionView:self.collectionView decorationViewIdentiferAtSection:section];
            
            if(identifer)
            {
                UICollectionViewLayoutAttributes *decorationAttributes=[UICollectionViewLayoutAttributes layoutAttributesForDecorationViewOfKind:identifer withIndexPath:[NSIndexPath indexPathForItem:0 inSection:section]];
                decorationAttributes.frame=sectionFrame;
                decorationAttributes.zIndex=-1;
                [self.decorationViews addObject:decorationAttributes];
            }
        }else
        {
            continue;
        }
        
    }
    
}

- (NSArray *)layoutAttributesForElementsInRect:(CGRect)rect {
    NSArray *attributes = [super layoutAttributesForElementsInRect:rect];
    
    NSMutableArray *allAttributes = [NSMutableArray arrayWithArray:attributes];
  
    [allAttributes addObjectsFromArray:[self.decorationViews filteredArrayUsingPredicate:[NSPredicate predicateWithBlock:^BOOL(id  _Nullable evaluatedObject, NSDictionary<NSString *,id> * _Nullable bindings) {
        UICollectionViewLayoutAttributes *obj=evaluatedObject;
        return CGRectIntersectsRect(rect, obj.frame);
    }]]];
    
    return allAttributes;
}
- (BOOL)shouldInvalidateLayoutForBoundsChange:(CGRect)newBounds
{
    return YES;
}


@end

