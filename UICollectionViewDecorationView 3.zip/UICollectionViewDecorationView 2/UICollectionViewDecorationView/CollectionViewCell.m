//
//  CollectionViewCell.m
//  UICollectionViewDecorationView
//
//  Created by 魏鹏程 on 16/6/19.
//  Copyright © 2016年 魏鹏程. All rights reserved.
//

#import "CollectionViewCell.h"

@implementation CollectionViewCell
-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if(self)
    {
        self.contentView.backgroundColor=[UIColor orangeColor];
    }
    return self;
}
@end
