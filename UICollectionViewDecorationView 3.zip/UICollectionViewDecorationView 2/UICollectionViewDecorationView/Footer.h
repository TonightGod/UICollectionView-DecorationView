//
//  Footer.h
//  UICollectionViewDecorationView
//
//  Created by 魏鹏程 on 2017/1/16.
//  Copyright © 2017年 魏鹏程. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Footer : UICollectionReusableView

@end
