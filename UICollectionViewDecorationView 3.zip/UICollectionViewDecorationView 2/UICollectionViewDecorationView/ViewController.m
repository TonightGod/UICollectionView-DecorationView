//
//  ViewController.m
//  UICollectionViewDecorationView
//
//  Created by 魏鹏程 on 16/6/19.
//  Copyright © 2016年 魏鹏程. All rights reserved.
//

#import "ViewController.h"
#import "CollectionViewCell.h"
#import "MyCustomLayout.h"
#import "CollectionReusableView.h"
static NSString *kDecorationReuseIdentifier = @"section_background";
static NSString *kTestNibCollectionReusableView= @"TestNibCollectionReusableView";

@interface ViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,MyCustomLayoutDelegate>

@property(nonatomic,strong) UICollectionView *collectionView;

@property(nonatomic,strong) NSMutableArray *dataArray;
@end

@implementation ViewController

-(NSMutableArray*)dataArray
{
    if(!_dataArray)
    {
        _dataArray=[NSMutableArray array];
        NSArray *items=@[@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@""];
        NSMutableArray *mutl=[NSMutableArray arrayWithArray:items];
        [_dataArray addObject:[mutl mutableCopy]];
        [_dataArray addObject:[mutl mutableCopy]];
        
        [_dataArray addObject:[mutl mutableCopy]];
        
        [_dataArray addObject:[mutl mutableCopy]];
        
        
    }
    return _dataArray;
}

-(UICollectionView *)collectionView
{
    if(!_collectionView)
    {
        MyCustomLayout *layout=[[MyCustomLayout alloc]init];
        layout.delegate=self;
        [layout registerClass:[CollectionReusableView class] forDecorationViewOfKind:kDecorationReuseIdentifier];
        [layout registerNib:[UINib nibWithNibName:@"TestNibCollectionReusableView" bundle:nil] forDecorationViewOfKind:kTestNibCollectionReusableView];
        layout.sectionInset=UIEdgeInsetsMake(8, 8, 8, 8);
        layout.minimumLineSpacing=10;
        layout.minimumInteritemSpacing=10;
        layout.itemSize=CGSizeMake(100, 100);
        _collectionView=[[UICollectionView alloc]initWithFrame:self.view.bounds collectionViewLayout:layout];
        [_collectionView registerClass:[CollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
        [_collectionView registerNib:[UINib nibWithNibName:@"Header" bundle:nil] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"Header"];
        [_collectionView registerNib:[UINib nibWithNibName:@"Footer" bundle:nil] forSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:@"Footer"];
        _collectionView.backgroundColor=[UIColor grayColor];
        _collectionView.dataSource=self;
        _collectionView.delegate=self;
    }
    return _collectionView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view addSubview:self.collectionView];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        [self.collectionView performBatchUpdates:^{
            [self.dataArray removeObjectAtIndex:0];
            [self.collectionView deleteSections:[NSIndexSet indexSetWithIndex:0]];
//        } completion:^(BOOL finished) {
//            [self.collectionView reloadData];
//        }];
    });
    
}
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return self.dataArray.count;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
   
    return [self.dataArray[section] count];
}
-(UICollectionViewCell*)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    return cell;
}

-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    if(section%2==0)
    {
        return UIEdgeInsetsMake(40, 40, 40, 40);
    }
    return UIEdgeInsetsMake(8, 8, 8, 8);
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section%2==0)
    {
        return CGSizeMake((collectionView.frame.size.width-40-40), (collectionView.frame.size.width-40-40)/5);
    }
    return CGSizeMake((collectionView.frame.size.width-16-80), (collectionView.frame.size.width-16-80)/5);

}


-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    return CGSizeMake(collectionView.frame.size.width, 50);
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForFooterInSection:(NSInteger)section
{
    return CGSizeMake(collectionView.frame.size.width, 50);

}

-(UICollectionReusableView*)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    if(kind==UICollectionElementKindSectionHeader)
    {
        return [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:@"Header" forIndexPath:indexPath];
    }else
    {
       return  [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:@"Footer" forIndexPath:indexPath];
    }
}

-(NSString*)collectionView:(UICollectionView *)collectionView decorationViewIdentiferAtSection:(NSInteger)section
{
    if(section%2==0)
    {
        return kTestNibCollectionReusableView;
    }
    
    return nil;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
    

}

@end
