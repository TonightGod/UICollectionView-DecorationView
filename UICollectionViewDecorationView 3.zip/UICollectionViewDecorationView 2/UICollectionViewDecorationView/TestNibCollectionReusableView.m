//
//  TestNibCollectionReusableView.m
//  UICollectionViewDecorationView
//
//  Created by 魏鹏程 on 2017/1/14.
//  Copyright © 2017年 魏鹏程. All rights reserved.
//

#import "TestNibCollectionReusableView.h"

@implementation TestNibCollectionReusableView

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)applyLayoutAttributes:(UICollectionViewLayoutAttributes *)layoutAttributes
{
    [super applyLayoutAttributes:layoutAttributes];
    layoutAttributes.zIndex=-1;
}

@end
