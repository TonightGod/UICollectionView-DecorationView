//
//  CollectionReusableView.h
//  UICollectionViewDecorationView
//
//  Created by 魏鹏程 on 16/6/19.
//  Copyright © 2016年 魏鹏程. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionReusableView : UICollectionReusableView

@end
